﻿using EDA.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.Device
{
    

    public class ADC
    {
        private List<string> possibleAmp = new List<string>();
        private List<string> possibleRes = new List<string>();

        public ADC()
        {
            possibleAmp.AddRange(new List<string>
            {
                "1",
                "2",
                "4",
                "8"
            });
            possibleRes.AddRange(new List<string>
            {
                "16",
                "18"
            });
            Amplifier = 2;
            Resolution = 16;
        }

        public int Amplifier { get; set; }
        public int Resolution { get; set; }
    }

}
