﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.Device
{
    public class Bridge
    {
        public Bridge()
        {
            _power = 2.5;
        }


        private double _power;
        public double Power
        {
            get
            {
                return _power;
            }
            set
            {
                _power = (value * 807) / 664000000;
            }
        }
    }
}
