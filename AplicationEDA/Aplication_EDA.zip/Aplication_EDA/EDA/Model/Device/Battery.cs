﻿using EDA.Home;
using EDA.Logic;
using EDA.Logic.Communication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.Device
{
    public class Battery
    {
        private double _batteryStatus;
        public Action<double> changeBattery;
         
        public Battery()
        {
        }

        public void SetBatteryState(double value)
        {
            double vBat = ((value * 210)/22528) - 5;
            double per = (vBat * 100) / 4;
            if (per > 100) per = 100;
            if (per < 0) per = 0;
            BatteryStatus = per;
        }
        
        public double BatteryStatus
        {
            get
            {
                return _batteryStatus;
            }
            set
            {
                _batteryStatus = value;
                changeBattery?.Invoke(value);
            }
        }
        
    }
}
