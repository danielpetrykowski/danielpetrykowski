﻿using EDA.Logic;
using EDA.Logic.Communication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.Device
{
    public class Potentiometer 
    {
        
        public Potentiometer()
        {
            PotentiometerValue = 0;
        }

        public int PotentiometerValue { get; set; }
    }
}
