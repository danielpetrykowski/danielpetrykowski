﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.Device
{
    public class Device
    {
        public ADC aDC;
        public Potentiometer potentiometer;
        public Battery battery;
        public Bridge bridge;

        public Action<double> CalcuResAction;
        public Action<double> RangeMaxAction;
        public Action<double> RangeMinAction;

        public Device()
        {
            aDC = new ADC();
            potentiometer = new Potentiometer();
            battery = new Battery();
            bridge = new Bridge();

            ResolutionOm = 0;
            RangeMinOm = 0;
            RangeMaxOm = 0;
            ResolutionS = 0;
            RangeMinS = 0;
            RangeMaxS = 0;
            ModeRes = true;
            StartTime = DateTime.Now;
        }

        private bool _modeRes;
        public bool ModeRes
        {
            get
            {
                return _modeRes;
            }
            set
            {
                _modeRes = value;
            }
        }

        private double _resolutionOm;
        public double ResolutionOm
        {
            get
            {
                return _resolutionOm;
            }
            set
            {
                _resolutionOm = value;
            }
        }

        private double _rangeMinOm;
        public double RangeMinOm
        {
            get
            {
                return _rangeMinOm;
            }
            set
            {
                _rangeMinOm = value;
            }
        }

        private double _rangeMaxOm;
        public double RangeMaxOm
        {
            get
            {
                return _rangeMaxOm;
            }
            set
            {
                _rangeMaxOm = value;
            }
        }

        private double _resolutionS;
        public double ResolutionS
        {
            get
            {
                return _resolutionS;
            }
            set
            {
                _resolutionS = value;
            }
        }

        private double _rangeMinS;
        public double RangeMinS
        {
            get
            {
                return _rangeMinS;
            }
            set
            {
                _rangeMinS = value;
            }
        }

        private double _rangeMaxS;
        public double RangeMaxS
        {
            get
            {
                return _rangeMaxS;
            }
            set
            {
                _rangeMaxS = value;
            }
        }

        public DateTime StartTime { get; set; }

        public void SetResolution(List<double> value)
        {
            ResolutionOm = value[0];
            ResolutionS = value[1];
            if (ModeRes)
                CalcuResAction?.Invoke(value[0]);
            else
                CalcuResAction?.Invoke(value[1]);
        }

        public void SetRange(List<double> value)
        {
            RangeMinOm = value[0];
            RangeMaxOm = value[1];
            RangeMinS = value[2];
            RangeMaxS = value[3];
            if (ModeRes)
            {
                RangeMinAction?.Invoke(RangeMinOm);
                RangeMaxAction?.Invoke(RangeMaxOm);
            }
            else
            {
                RangeMinAction?.Invoke(RangeMinS);
                RangeMaxAction?.Invoke(RangeMaxS);
            }
        }
    }
}
