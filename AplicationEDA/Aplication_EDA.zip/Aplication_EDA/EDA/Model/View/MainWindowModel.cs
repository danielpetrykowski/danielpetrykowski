﻿using EDA.Logic;
using EDA.Logic.Communication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EDA.Model.View
{
    public class MainWindowModel : INotifyPropertyChanged
    {
        private double _batteryStatus;
        private double _sPS;
        private double _resolution;
        private double _rangeMin;
        private double _rangeMax;
        bool _isActive;
        private String _rangeUnit;
        private String _resContentUnit;

        public MainWindowModel()
        {
            BatteryStatus = 0;
            SPS = 0;
            Resolution = 0;
            RangeMax = 0;
            RangeMin = 0;
            RangeUnit = "kΩ";
            ResContentUnit = "Ω";
            IsActive = false;
        }
        
        public double BatteryStatus
        {
            get
            {
                return _batteryStatus;
            }
            set
            {
                _batteryStatus = value;
                OnPropertyChanged("BatteryStatus");
            }
        }

        public double SPS
        {
            get
            {
                return _sPS;
            }
            set
            {
                _sPS = value;
                OnPropertyChanged("SPS");
            }
        }

        public double Resolution
        {
            get
            {
                return _resolution;
            }
            set
            {
                _resolution = value;
                OnPropertyChanged("Resolution");
            }
        }

        public double RangeMin
        {
            get
            {
                return _rangeMin;
            }
            set
            {
                _rangeMin = value;
                OnPropertyChanged("RangeMin");
            }
        }

        public double RangeMax
        {
            get
            {
                return _rangeMax;
            }
            set
            {
                _rangeMax = value;
                OnPropertyChanged("RangeMax");
            }
        }

        public bool IsActive
        {
            get
            {
                return _isActive;
            }
            set
            {
                _isActive = value;
                OnPropertyChanged("IsActive");
            }
        }

        public String RangeUnit
        {
            get
            {
                return _rangeUnit;
            }
            set
            {
                _rangeUnit = value;
                OnPropertyChanged("RangeUnit");
            }
        }

        public String ResContentUnit
        {
            get
            {
                return _resContentUnit;
            }
            set
            {
                _resContentUnit = value;
                OnPropertyChanged("ResContentUnit");
            }
        }


        public object SaveCommand { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
