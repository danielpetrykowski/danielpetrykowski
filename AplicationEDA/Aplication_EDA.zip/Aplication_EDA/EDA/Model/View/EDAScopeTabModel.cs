﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.View
{
    public class EDAScopeTabModel : INotifyPropertyChanged
    {
        private string _amplifierStatus;
        private bool _amplifierAuto;
        public List<string> possibleAmp = new List<string>();
        private double _potentiometerStatus;
        private bool _potentiometerAuto;
        private String _startStopBL;

        public EDAScopeTabModel()
        {
            IsStart = false;
            Init = false;
            possibleAmp.AddRange(new List<string>
            {
                "1",
                "2",
                "4",
                "8"
            });
            AmplifierAuto = true;
            AmplifierStatus = "2";
            PotentiometerAuto = true;
            PotentiometerStatus = 0;
            StartStopBL = "Start";
        }

        public bool IsStart { get; set; }
        public bool Init { get; set; }
        public String StartStopBL
        {
            get
            {
                return _startStopBL;
            }
            set
            {
                _startStopBL = value;
                OnPropertyChanged("StartStopBL");
            }
        }
        public bool AmplifierAuto
        {
            get
            {
                return _amplifierAuto;
            }
            set
            {
                _amplifierAuto = value;
                OnPropertyChanged("AmplifierAuto");
            }
        }

        public string AmplifierStatus
        {
            get
            {
                return _amplifierStatus;
            }
            set
            {
                if (possibleAmp.Contains(value))
                {
                    _amplifierStatus = value;
                    OnPropertyChanged("AmplifierStatus");
                }
            }
        }

        public bool PotentiometerAuto
        {
            get
            {
                return _potentiometerAuto;
            }
            set
            {
                _potentiometerAuto = value;
                OnPropertyChanged("PotentiometrAuto");
            }
        }

        public double PotentiometerStatus
        {
            get
            {
                return _potentiometerStatus;
            }
            set
            {
                if (value >= 0 && value <= 255)
                {
                    _potentiometerStatus = value;
                    OnPropertyChanged("PotentiometerStatus");
                }
            }
        }

        public object StartStopCommand { get; set; }
        public object ClearCommand { get; set; }

        #region INotifyPropertyChanged implementation

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            if (PropertyChanged != null)
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
