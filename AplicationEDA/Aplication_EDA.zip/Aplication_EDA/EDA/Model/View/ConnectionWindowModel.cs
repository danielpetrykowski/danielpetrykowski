﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.View
{
    public class ConnectionWindowModel : INotifyPropertyChanged
    {
        private String _portName;
        private String _baudrate;
        private String _dataBits;
        private String _parityBits;
        private String _stopBits;

        public ObservableCollection<String> PortsNameList { get; set; }
        public ObservableCollection<String> ConnectionSpeedList { get; set; }
        public ObservableCollection<String> DataBitsList { get; set; }
        public ObservableCollection<String> ParityList { get; set; }
        public ObservableCollection<String> StopBitsList { get; set; }

        public object ConnectCommand { get; set; }
        public object RefreshCommand { get; set; }

        public String PortName
        {
            get
            {
                return _portName;
            }
            set
            {
                _portName = value;
                OnPropertyChanged("PortName");
            }
        }

        public String Baudrate
        {
            get
            {
                return _baudrate;
            }
            set
            {
                _baudrate = value;
                OnPropertyChanged("Baudrate");
            }
        }

        public String DataBits
        {
            get
            {
                return _dataBits;
            }
            set
            {
                _dataBits = value;
                OnPropertyChanged("DataBits");
            }
        }

        public String ParityBits
        {
            get
            {
                return _parityBits;
            }
            set
            {
                _parityBits = value;
                OnPropertyChanged("ParityBits");
            }
        }

        public String StopBits
        {
            get
            {
                return _stopBits;
            }
            set
            {
                _stopBits = value;
                OnPropertyChanged("StopBits");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
