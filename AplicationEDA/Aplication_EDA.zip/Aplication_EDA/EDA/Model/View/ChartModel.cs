﻿using EDA.Model.Data;
using LiveCharts;
using LiveCharts.Configurations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.View
{
    public class ChartModel : INotifyPropertyChanged
    {
        private double _axisMax;
        private double _axisMin;
        private String _labelY;

        public ChartModel()
        {
            var mapper = Mappers.Xy<ChartData>()
               .X(model => model.Time.Ticks)
               .Y(model => model.Value);

            Charting.For<ChartData>(mapper);

            ChartValues = new ChartValues<ChartData>();

            DateTimeFormatter = value => new TimeSpan((long)value).TotalSeconds.ToString();

            AxisStep = TimeSpan.FromSeconds(1).Ticks;
            AxisUnit = TimeSpan.TicksPerSecond;
        }

        public ChartValues<ChartData> ChartValues { get; set; }
        public Func<double, string> DateTimeFormatter { get; set; }
        public double AxisStep { get; set; }
        public double AxisUnit { get; set; }

        public double AxisMax
        {
            get { return _axisMax; }
            set
            {
                _axisMax = value;
                OnPropertyChanged("AxisMax");
            }
        }
        public double AxisMin
        {
            get { return _axisMin; }
            set
            {
                _axisMin = value;
                OnPropertyChanged("AxisMin");
            }
        }

        public String LabelY
        {
            get { return _labelY; }
            set
            {
                _labelY = value;
                OnPropertyChanged("LabelY");
            }
        }


        #region INotifyPropertyChanged implementation

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            if (PropertyChanged != null)
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
