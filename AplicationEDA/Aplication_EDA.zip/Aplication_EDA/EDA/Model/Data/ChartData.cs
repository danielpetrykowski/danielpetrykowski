﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model
{
    public class ChartData
    {
        public TimeSpan Time { get; set; }
        public double Value { get; set; }
    }
}
