﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Model.Data
{
    public class MeasureData
    {
        private double _valueRes;

        public DateTime Time { get; set; }
        public double ValueRes
        {
            get
            {
                return _valueRes;
            }
            set
            {
                _valueRes = value;
                ValueCon = 1 / value;            
            }
        }
        public double ValueCon { get; private set; }
        public double ResolutionOm { get; set; }
        public double RangeMinOm { get; set; }
        public double RangeMaxOm { get; set; }
        public double ResolutionS { get; set; }
        public double RangeMinS { get; set; }
        public double RangeMaxS { get; set; }
        public int ADC_Resolution { get; set; }
        public int ADC_OpAmp { get; set; }
        public int Potentiometer { get; set; }
    }
}
