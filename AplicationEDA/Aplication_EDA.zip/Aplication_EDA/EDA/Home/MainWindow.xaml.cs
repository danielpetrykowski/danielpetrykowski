﻿using EDA.Components.ConnectionWindow;
using EDA.Components.LiveChart;
using EDA.Logic;
using EDA.Logic.Communication;
using EDA.Model.Device;
using System;
using System.Threading;
using System.Windows;

namespace EDA.Home
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainWindowMV();
        }

        private void Window_ContentRender(object sender, EventArgs e)
        {
            ConnectionWindow cw = new ConnectionWindow
            {
                Owner = this,
                ShowInTaskbar = false,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };
            cw.ShowDialog();
        }

        private void Window_Closing(object sender, EventArgs e)
        {
            if ((Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).IsActive)
            {
                CommandEDA.StopEDA();
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).ConnectClose();
            }
        }

        private void TabScope_InitFalse()
        {
            var scope = Scope.DataContext as ChartVM;
            scope.UpdateStartTime();
        }

        private void TabScope_ClearEvent()
        {
            var scope = Scope.DataContext as ChartVM;
            scope.Clear();
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.data.Clear();
            scope.InitAxis();
            scope.UpdateStartTime();
        }

        private void TabScope_RbMode(string obj)
        {
            var scope = Scope.DataContext as ChartVM;
            var dc = this.DataContext as MainWindowMV;
            dc.ChangeUnit(obj);
            scope.ChangeY(obj);
        }
    }
}
