﻿using EDA.Logic;
using EDA.Logic.Communication;
using EDA.Logic.Control;
using EDA.Model.Device;
using EDA.Model.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EDA.Home
{
    class MainWindowMV
    {
        private MainWindowModel mainWindowModel;

        public MainWindowMV()
        {
            mainWindowModel = new MainWindowModel();
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).IsActiveAction += ChangeIsActive;
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.device.battery.changeBattery += ChangeBattery;
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.samplePerSecond.changeSPS += ChangeSPS;
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.device.CalcuResAction += ChangeResolution;
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.device.RangeMinAction += ChangeRangeMin;
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.device.RangeMaxAction += ChangeRangeMax;
            MainWindowModel.SaveCommand = Saver.SaveCommand;
        }

        public MainWindowModel MainWindowModel
        {
            get
            {
                return mainWindowModel;
            }
            set
            {
                mainWindowModel = value;
            }
        }
        
        
        private void ChangeIsActive(bool value)
        {
            MainWindowModel.IsActive = value;
        }

        private void ChangeResolution(double value)
        {
            MainWindowModel.Resolution = value;
        }

        private void ChangeBattery(double value)
        {
            MainWindowModel.BatteryStatus = value;
        }

        private void ChangeSPS(double value)
        {
            MainWindowModel.SPS = value;
        }

        private void ChangeRangeMin(double value)
        {
            MainWindowModel.RangeMin = value;
        }

        private void ChangeRangeMax(double value)
        {
            MainWindowModel.RangeMax = value;
        }

        public void ChangeUnit(string value)
        {
            Device device = (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.device;
            if (value.Equals("Resistance"))
            {
                MainWindowModel.RangeUnit = "kΩ";
                MainWindowModel.ResContentUnit = "Ω";
                device.ModeRes = true;
                device.SetRange(CalculateData.CalcuRange(device));
                device.SetResolution(new List<double> { 0,0 });
            }
            else
            {
                MainWindowModel.RangeUnit = "mS";
                MainWindowModel.ResContentUnit = "S";
                device.ModeRes = false;
                device.SetRange(CalculateData.CalcuRange(device));
                device.SetResolution(new List<double> { 0, 0 });
            }
        }
    }
}
