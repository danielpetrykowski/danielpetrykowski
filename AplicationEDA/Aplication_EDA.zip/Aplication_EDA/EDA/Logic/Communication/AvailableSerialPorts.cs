﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Logic.Communication
{
    public class AvailableSerialPorts
    {
        public List<String> portsName = new List<string>();
        public List<String> parity = new List<string>();
        public List<String> stopBits = new List<string>();
        public List<String> connectionSpeed = new List<string>();
        public List<String> dataBits = new List<string>();
        

        public AvailableSerialPorts()
        {
            RefreshPortsName();
            RefreshParity();
            RefreshStopBits();
            InitConnectionSpeed();
            InitDataBits();
        }

        public void Refresh()
        {
            RefreshPortsName();
        }

        private void RefreshPortsName()
        {
            portsName.Clear();
            foreach (String s in SerialPort.GetPortNames()) portsName.Add(s);
        }

        private void RefreshParity()
        {
            foreach (String s in Enum.GetNames(typeof(Parity))) parity.Add(s);
        }

        private void RefreshStopBits()
        {
            foreach (String s in Enum.GetNames(typeof(StopBits))) stopBits.Add(s);
        }

        private void InitConnectionSpeed()
        {
            connectionSpeed.AddRange(new List<String>
            {
                "2400",
                "4800",
                "9600",
                "14400",
                "19200",
                "28800",
                "38400",
                "57600",
                "76800",
                "115200",
                "230400"
            });
        }

        private void InitDataBits()
        {
            dataBits.AddRange(new List<String>
            {
                "5",
                "6",
                "7",
                "8",
                "9"
            });
        }

    }
}
