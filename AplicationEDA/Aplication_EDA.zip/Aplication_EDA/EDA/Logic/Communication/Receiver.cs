﻿using System;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Windows;

namespace EDA.Logic.Communication
{
    public class Receiver
    {
        public static Action<string> clearData;
        public static Action<DateTime> samplePerSecondAction;
        public SamplePerSecond samplePerSecond = new SamplePerSecond();
        public Engine engine = new Engine();
         
        public Receiver()
        {
            samplePerSecondAction = samplePerSecond.CountsPS;
        }
        
        public void DataRecievedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            String data = (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).ReadLine().ToString();
            DateTime nowPC = DateTime.Now;
            Task.Factory.StartNew(() => { samplePerSecondAction(nowPC); });
            clearData.Invoke(data);
            engine.ReadCommend(data);
        }
    }
}
