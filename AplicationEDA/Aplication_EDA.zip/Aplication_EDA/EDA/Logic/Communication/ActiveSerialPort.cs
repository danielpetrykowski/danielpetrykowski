﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.ComponentModel;
using System.Windows;
using System.Diagnostics;
using System.Threading;

namespace EDA.Logic.Communication
{
    class ActiveSerialPort : SerialPort
    {

        bool _isActive;
        public Action<bool> IsActiveAction;
        public Receiver conData = new Receiver();


        public ActiveSerialPort()
        {
            ReadTimeout = 500;
            WriteTimeout = 500;
            _isActive = false;
            DataReceived += new SerialDataReceivedEventHandler(conData.DataRecievedHandler);
        }

        public bool IsActive
        {
            get
            {
                return _isActive;
            }
            set
            {
                _isActive = value;
                IsActiveAction?.Invoke(value);
            }
        }
        
        public bool ConnectOpen()
        {
            if (!IsOpen)
            {
                try
                {
                    Open();
                }
                catch (Exception exc)
                {
                    MessageBox.Show("Błąd połączenia: \n" + exc.Message);
                    return false;
                }
                IsActive = true;
                CommandEDA.StopEDA();
                Thread.Sleep(500);
                CommandEDA.CheckBattery();
                Thread.Sleep(500);
                CommandEDA.Info();
                return true;
            }
            return false;
        }

        public bool ConnectClose()
        {
            if (IsOpen)
            {
                CommandEDA.StopEDA();
                Close();
                IsActive = false;
                return true;
            }else if (IsActive != IsOpen)
            {
                Close();
                IsActive = false;
            }
            return false;
        }



    }
}
