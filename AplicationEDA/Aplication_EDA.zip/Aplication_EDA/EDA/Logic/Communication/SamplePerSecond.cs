﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Logic.Communication
{
    public class SamplePerSecond
    {
        private Queue<DateTime> date = new Queue<DateTime>();
        private const int period = 20;
        public Action<double> changeSPS;

        public SamplePerSecond()
        {
            SPS = 0;
        }

        public void CountsPS(DateTime now)
        {
            date.Enqueue(now);
            if (date.Count == period+1)
            {
                DateTime prev = date.Dequeue();
                TimeSpan span = now - prev;
                SPS = 20000 / span.TotalMilliseconds;
            }
        }

        private double _sPS;

        public double SPS
        {
            get
            {
                return _sPS;
            }
            set
            {
                _sPS = value;
                changeSPS?.Invoke(value);
            }
        }
    }
}
