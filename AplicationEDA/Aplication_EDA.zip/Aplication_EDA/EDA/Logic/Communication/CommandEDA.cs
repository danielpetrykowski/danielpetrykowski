﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EDA.Logic.Communication
{
    public static class CommandEDA
    {
        private static Action<List<int>> lastCommend;
        private static List<int> lastPar = null;
        public static bool stop = false;

        public static void StartEDA(List<int> par = null)
        {
            SendData("1");
            lastCommend = StartEDA;
            CommandEDA.lastPar = null;
            stop = false;
        }

        public static void StopEDA(List<int> par = null)
        {
            SendData("2");
            lastCommend = StopEDA;
            CommandEDA.lastPar = null;
        }

        public static void CheckBattery(List<int> par = null)
        {
            SendData("3");
            lastCommend = CheckBattery;
            CommandEDA.lastPar = null;
        }

        public static void SettingMeasure(List<int> par)
        {
            String commend = "4/" + par[0].ToString() + "/" + par[1].ToString();
            SendData(commend);
            lastCommend = SettingMeasure;
            CommandEDA.lastPar = par;
        }

        public static void Potentiometer(List<int> par)
        {
            String commend = "5/" + par[0].ToString();
            SendData(commend);
            lastCommend = Potentiometer;
            CommandEDA.lastPar = par;
        }

        public static void Amplifier(List<int> par)
        {
            String commend = "6/" + par[0].ToString();
            SendData(commend);
            lastCommend = Amplifier;
            CommandEDA.lastPar = par;
        }

        public static void Resolution(List<int> par)
        {
            String commend = "7/" + par[0].ToString();
            SendData(commend);
            lastCommend = Resolution;
            CommandEDA.lastPar = par;
        }

        public static void VoltageBridge(List<int> par = null)
        {
            SendData("8");
            lastCommend = VoltageBridge;
            CommandEDA.lastPar = par;
        }

        public static void Info(List<int> par = null)
        {
            SendData("9");
            lastCommend = Info;
            CommandEDA.lastPar = null;
        }

        public static void Retransmision()
        {
            if (stop)
            {
                StartEDA();
            }
            else
            {
                lastCommend(CommandEDA.lastPar);
            }            
        }

        private static void SendData(String value)
        {
            var serialPort = (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort);
            try
            {
                serialPort.Write(value);
            }
            catch (InvalidOperationException e)
            {
               if (serialPort.IsOpen != serialPort.IsActive)
                {
                    serialPort.Close();
                    serialPort.IsActive = false;
                }
            }
        }
    }
}
