﻿using EDA.Logic.Communication;
using EDA.Model.Data;
using EDA.Utility;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace EDA.Logic
{
    public static class Saver
    {
        public static RelayCommand SaveCommand = new RelayCommand(x => { OpenSaveWindow(); }, x => true);

        
        private static void OpenSaveWindow()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog()
            {
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                Filter = "CSV (*.csv)|*.csv",
                ValidateNames = true,
                FileName = DateTime.Now.ToString("dd.MM.yyyy_hh.mm.ss")
            };
            if (saveFileDialog.ShowDialog() == true)
                SaveDataToExcel(saveFileDialog.FileName);

        }

        private async static void SaveDataToExcel(string name)
        {
            Data data = (System.Windows.Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.data;
            using(StreamWriter sw = new StreamWriter(new FileStream(name,FileMode.Create)))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Time;Resistance [kOhm];Conductance [S];Resolution [Ohm];Resolution [S];RangeMin [kOhm];Range Min [mS];Range Max [kOhm];Range Max [mS];ADC Resolution;ADC OpAmp;Potentiometer");
                foreach(MeasureData item in data.MeasureDatas)
                {
                    sb.Append(string.Format("{0};", item.Time.ToString("hh:mm:ss,fff")));
                    sb.Append(string.Format("{0};", item.ValueRes.ToString()));
                    sb.Append(string.Format("{0};", item.ValueCon.ToString()));
                    sb.Append(string.Format("{0};", item.ResolutionOm.ToString()));
                    sb.Append(string.Format("{0};", item.ResolutionS.ToString()));
                    sb.Append(string.Format("{0};", item.RangeMinOm.ToString()));
                    sb.Append(string.Format("{0};", item.RangeMinS.ToString()));
                    sb.Append(string.Format("{0};", item.RangeMaxOm.ToString()));
                    sb.Append(string.Format("{0};", item.RangeMaxS.ToString()));
                    sb.Append(string.Format("{0};", item.ADC_Resolution.ToString()));
                    sb.Append(string.Format("{0};", item.ADC_OpAmp.ToString()));
                    sb.AppendLine(string.Format("{0}", item.Potentiometer.ToString()));
                }
                await sw.WriteLineAsync(sb.ToString());
            }
        }
    }
}
