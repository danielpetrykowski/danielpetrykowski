﻿using EDA.Model;
using EDA.Model.Data;
using EDA.Model.Device;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Logic
{
    public class Data
    {
        public List<MeasureData> MeasureDatas { get; }

        public Data()
        {
            MeasureDatas = new List<MeasureData>();
        }

        public void AddData(DateTime time, double data, int amp, int pot, Device device)
        {
            MeasureDatas.Add(new MeasureData
            {
                Time = time,
                ValueRes = data,
                ResolutionOm = device.ResolutionOm,
                RangeMinOm = device.RangeMinOm,
                RangeMaxOm = device.RangeMaxOm,
                ResolutionS = device.ResolutionS,
                RangeMinS = device.RangeMinS,
                RangeMaxS = device.RangeMaxS,
                ADC_OpAmp = amp,
                Potentiometer = pot,
                ADC_Resolution = device.aDC.Resolution
            });
        }

        public void Clear()
        {
            MeasureDatas.Clear();
        }
    }
}
