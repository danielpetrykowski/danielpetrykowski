﻿using EDA.Model.Device;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Logic.Control
{
    public class CalculateData
    {
        private const int r7 = 100000;
        private const int r5 = 220000;
        private const int r6 = 220000;
        private const int Limit = 600000;
        
        public static double Converting(double measure, double amplifier, double potentiometer, double power)
        {
            double resRef = (0.3873 * potentiometer + 0.1051) * 1000 + r7;
            double measureVoltage = (measure / 1000000);
            double i14 = power / (r6 + resRef);
            double u4 = i14 * resRef;
            double u3 = measureVoltage + u4;
            double resOut = ((u3 * r5) / (power - u3)) / 1000;     // kom

            if (resOut <= 0 || resOut > Limit)
            {
                resOut = Limit;
            }
            return resOut;
        }

        public static List<double> CalcuResolution(double measure, Device device)
        {
            double xadc = 4.096 / (Math.Pow(2,device.aDC.Resolution)*device.aDC.Amplifier);
            double resRef = (0.3873 * device.potentiometer.PotentiometerValue + 0.1051) * 1000 + r7;
            double ux = (measure/1000000)*device.aDC.Amplifier + ((device.bridge.Power*resRef)/(r6+resRef));
            double xc = (device.bridge.Power*xadc*r5) / ((device.bridge.Power-ux)*(device.bridge.Power-ux-xadc));

            double oxcPom = (ux * Math.Pow(r5, 2) * (ux + xadc)) / ((device.bridge.Power - ux) * (device.bridge.Power - ux - xadc));
            double xcp = xc / oxcPom;
            
            return new List<double> { xc, xcp };
        }
        
        public static List<double> CalcuRange(Device device)
        {
            double vMin = -2.048 / device.aDC.Amplifier;
            double vMax = 2.048 / device.aDC.Amplifier;
            double resRef = (0.3873 * device.potentiometer.PotentiometerValue + 0.1051) * 1000 + r7;
            double i14 = device.bridge.Power / (r6 + resRef);
            double u4 = i14 * resRef;
            double u3Min = vMin + u4;
            double u3Max = vMax + u4;
            double resOutMin = ((u3Min * r5) / (device.bridge.Power - u3Min)) / 1000;
            double resOutMax = ((u3Max * r5) / (device.bridge.Power - u3Max)) / 1000;
            if (resOutMin < 0)
            {
                resOutMin = 0;
            }
            if (resOutMax < 0)
            {
                resOutMax = Limit;
            }
            return new List<double> { resOutMin, resOutMax, 1/resOutMax, 1/resOutMin };
        }
    }
}
