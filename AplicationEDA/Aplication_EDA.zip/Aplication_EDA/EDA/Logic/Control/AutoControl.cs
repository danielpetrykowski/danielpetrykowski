﻿using EDA.Logic.Communication;
using EDA.Model.Data;
using EDA.Model.Device;
using EDA.Utility.Exception;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EDA.Logic.Control
{
    public class AutoControl
    {
        private const int Delay = 20;
        private const int Period = 3;
        private List<long> PointX = new List<long>();
        private List<double> PointY = new List<double>();

        public event Action<int> PotentiometerEvent;
        public event Action<int> AmplifierEvent;

        public AutoControl()
        {
            RemainingDelay = Delay;
        }

        private int RemainingDelay { get; set; }
        private int NewPotentiometerValue { get; set; }
        private int NewAmplifierValue { get; set; }


        public void Control(DateTime time, double measure, Device device, bool autoAmp, bool autoPot)
        {
            if (RemainingDelay == 0)
            {
                PointX.Add(time.Ticks);
                PointY.Add(measure);
                double percent = 0.01;
                if (PointX.Count > Period)
                {
                    PointX.RemoveAt(0);
                    PointY.RemoveAt(0);
                    if (autoAmp && autoPot)
                    {

                        int pot = device.potentiometer.PotentiometerValue;
                        int amp = device.aDC.Amplifier;
                        double rangeMax = device.RangeMaxOm - device.RangeMaxOm * percent;
                        double rangeMin = device.RangeMinOm + device.RangeMinOm * percent;

                        if (pot > 0 && measure < rangeMin)
                        {   
                            int newPot = pot - 50;
                            if (newPot < 0)
                            {
                                CommandPotentiometer(0);
                            }
                            else
                            {
                                CommandPotentiometer(newPot);
                            }
                        }
                        else if (amp == 8)
                        {
                            CommandAmplifier(2);
                        }
                        else if (amp == 4)
                        {
                            rangeMax = device.RangeMaxOm - device.RangeMaxOm * percent;
                            rangeMin = device.RangeMinOm + device.RangeMinOm * percent;
                            if (rangeMax < measure || rangeMin > measure)
                            {
                                CommandAmplifier(2);
                            }
                        }
                        else if (amp == 2)
                        {
                            rangeMax = device.RangeMaxOm - device.RangeMaxOm * percent;
                            rangeMin = device.RangeMinOm + device.RangeMinOm * percent;
                            if (rangeMax < measure || rangeMin > measure)
                            {
                                CommandAmplifier(1);
                            }
                            else
                            {
                                Device deviceNew = new Device
                                {
                                    aDC = new ADC
                                    {
                                        Amplifier = 4
                                    },
                                    potentiometer = device.potentiometer,
                                    bridge = device.bridge
                                };
                                List<double> range = CalculateData.CalcuRange(deviceNew);
                                double rangeMax4 = range[1];
                                rangeMax = rangeMax4 - rangeMax4 * percent;
                                double rangeMin4 = range[0];
                                rangeMin = rangeMin4 + rangeMin4 * percent;
                                if (rangeMax > measure && rangeMin < measure)
                                {
                                    CommandAmplifier(4);
                                }
                            }
                        }
                        else if (amp == 1)
                        {
                            rangeMax = device.RangeMaxOm - device.RangeMaxOm * percent;
                            rangeMin = device.RangeMinOm + device.RangeMinOm * percent;
                            if (rangeMax < measure)
                            {
                                SetPotentiometer(device, 50);
                            }
                            else
                            {
                                Device deviceNew = new Device
                                {
                                    aDC = new ADC
                                    {
                                        Amplifier = 2
                                    },
                                    potentiometer = device.potentiometer,
                                    bridge = device.bridge
                                };
                                List<double> range = CalculateData.CalcuRange(deviceNew);
                                double rangeMax4 = range[1];
                                rangeMax = rangeMax4 - rangeMax4 * percent;
                                double rangeMin4 = range[0];
                                rangeMin = rangeMin4 + rangeMin4 * percent;
                                if (rangeMax > measure && rangeMin < measure)
                                {
                                    CommandAmplifier(2);
                                }
                            }
                        }
                    }
                    else if (autoAmp && !autoPot)
                    {



                        int amp = device.aDC.Amplifier;
                        if (amp == 8)
                        {
                            CommandAmplifier(2);
                        }
                        else if (amp == 4)
                        {
                            double rangeMax = device.RangeMaxOm - device.RangeMaxOm * percent;
                            double rangeMin = device.RangeMinOm + device.RangeMinOm * percent;
                            if (rangeMax < measure || rangeMin > measure)
                            {
                                CommandAmplifier(2);
                            }
                        }
                        else if (amp == 2)
                        {
                            double rangeMax = device.RangeMaxOm - device.RangeMaxOm * percent;
                            double rangeMin = device.RangeMinOm + device.RangeMinOm * percent;
                            if (rangeMax < measure || rangeMin > measure)
                            {
                                CommandAmplifier(1);
                            }
                            else
                            {
                                Device deviceNew = new Device
                                {
                                    aDC = new ADC
                                    {
                                        Amplifier = 4
                                    },
                                    potentiometer = device.potentiometer,
                                    bridge = device.bridge
                                };
                                List<double> range = CalculateData.CalcuRange(deviceNew);
                                double rangeMax4 = range[1];
                                rangeMax = rangeMax4 - rangeMax4 * percent;
                                double rangeMin4 = range[0];
                                rangeMin = rangeMin4 + rangeMin4 * percent;
                                if (rangeMax > measure && rangeMin < measure)
                                {
                                    CommandAmplifier(4);
                                }
                            }
                        }
                        else if (amp == 1)
                        {
                            Device deviceNew = new Device
                            {
                                aDC = new ADC
                                {
                                    Amplifier = 2
                                },
                                potentiometer = device.potentiometer,
                                bridge = device.bridge
                            };
                            List<double> range = CalculateData.CalcuRange(deviceNew);
                            double rangeMax4 = range[1];
                            double rangeMax = rangeMax4 - rangeMax4 * percent;
                            double rangeMin4 = range[0];
                            double rangeMin = rangeMin4 + rangeMin4 * percent;
                            if (rangeMax > measure && rangeMin < measure)
                            {
                                CommandAmplifier(2);
                            }
                        }




                    }
                    else if (!autoAmp && autoPot)
                    {
                        if (device.RangeMaxOm - (device.RangeMaxOm * percent) < measure)
                        {
                            SetPotentiometer(device, 50);
                        }
                        else if (device.RangeMinOm + (device.RangeMinOm * percent) > measure)
                        {
                            SetPotentiometer(device, -50);
                        }
                    }
                }

                RemainingDelay = Delay;
            }
            else
            {
                RemainingDelay--;
            }
        }


        private int SetPotentiometer(Device device, int deltaValue)
        {
            if (device.potentiometer.PotentiometerValue == 250 && deltaValue > 0)
            {
                return 0;
            }
            if (device.potentiometer.PotentiometerValue == 0 && deltaValue < 0)
            {
                return 0;
            }
            int tmpPot = device.potentiometer.PotentiometerValue + deltaValue;
            if (tmpPot > 250)
            {
                tmpPot = 250;
            }
            else if (tmpPot < 0)
            {
                tmpPot = 0;
            }
            CommandPotentiometer(tmpPot);
            return 1;
        }


        private void CommandPotentiometer(int value)
        {
            CommandEDA.Potentiometer(new List<int> { value });
            PotentiometerEvent?.Invoke(value);
        }

        private void CommandAmplifier(int value)
        {
            CommandEDA.Amplifier(new List<int> { value });
            AmplifierEvent?.Invoke(value);
        }
    }
}
