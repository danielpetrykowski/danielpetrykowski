﻿using EDA.Logic.Communication;
using EDA.Logic.Control;
using EDA.Model.Device;
using EDA.Utility.Exception;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Logic
{
    public class Engine
    {
        public static Action<DateTime, double> measureData;
        public Data data = new Data();
        public Device device = new Device();
        public AutoControl autoControl = new AutoControl();
        public CalculateData calculateData = new CalculateData();

        public Engine()
        {
            device.ModeRes = true;
        }
        
        public bool AutoAmp { get; set; }
        public bool AutoPot { get; set; }

        public void ReadCommend(String value)
        {
            Debug.WriteLine(value);
            value = value.Trim('\r');
            string[] dataTab = value.Split('/');
            if (dataTab[0].Equals("M"))
            {
                DateTime time = device.StartTime + TimeSpan.FromMilliseconds(long.Parse(dataTab[1]));
                double measureV = Double.Parse(dataTab[2]);
                double potValue = Double.Parse(dataTab[3]);
                double ampValue = Double.Parse(dataTab[4]);
                

                double measureR = CalculateData.Converting(measureV, ampValue, potValue, device.bridge.Power);
                data.AddData(time, measureR,(int)ampValue, (int)potValue, device);
                measureData(time, measureR);
                

                Task.Factory.StartNew(() => {
                    try
                    {
                        device.SetResolution(CalculateData.CalcuResolution(measureV,device));
                        autoControl.Control(time, measureR, device, AutoAmp, AutoPot);
                    }
                    catch (MaxRangePotentiometer e)
                    {
                        Debug.WriteLine(e);
                    }
                    catch (MinRangePotentiometer e)
                    {
                        Debug.WriteLine(e);
                    }
                });
                
            }
            else if (dataTab[0].Equals("B"))
            {
                Action batt = () =>
                {
                    double battValue = Double.Parse(dataTab[1]);
                    device.battery.SetBatteryState(battValue);
                };
                Task.Factory.StartNew(batt);
            }
            else if (dataTab[0].Equals("V"))
            {
                device.bridge.Power = Double.Parse(dataTab[1]);
                device.SetRange(CalculateData.CalcuRange(device));
            }
            else if (dataTab[0].Equals("RES"))
            {
                int resValue = Int32.Parse(dataTab[1]);
                device.aDC.Resolution = resValue;

            }
            else if (dataTab[0].Equals("AMP"))
            {
                int ampValue = Int32.Parse(dataTab[1]);
                device.aDC.Amplifier = ampValue;
                device.SetRange(CalculateData.CalcuRange(device));
            }
            else if (dataTab[0].Equals("POT"))
            {
                int potValue = Int32.Parse(dataTab[1]);
                device.potentiometer.PotentiometerValue = potValue;
                device.SetRange(CalculateData.CalcuRange(device));
            }
            else if (dataTab[0].Equals("SET"))
            {
                int potValue = Int32.Parse(dataTab[1]);
                device.potentiometer.PotentiometerValue = potValue;
                int ampValue = Int32.Parse(dataTab[2]);
                device.aDC.Amplifier = ampValue;
                device.SetRange(CalculateData.CalcuRange(device));
            }
            else if (dataTab[0].Equals("INFO"))
            {
                int potValue = Int32.Parse(dataTab[1]);
                device.potentiometer.PotentiometerValue = potValue;
                int ampValue = Int32.Parse(dataTab[2]);
                device.aDC.Amplifier = ampValue;
                int resValue = Int32.Parse(dataTab[3]);
                device.aDC.Resolution = resValue;
                device.SetRange(CalculateData.CalcuRange(device));
            }
            else if (dataTab[0].Equals("STOP"))
            {
                CommandEDA.stop = true;
            }
            else if (dataTab[0].Equals("N"))
            {
                CommandEDA.Retransmision();
            }
        }
    }
}
