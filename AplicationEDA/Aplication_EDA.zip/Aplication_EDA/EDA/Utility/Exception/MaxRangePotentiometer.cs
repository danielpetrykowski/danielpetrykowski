﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDA.Utility.Exception
{
    [Serializable]
    public class MaxRangePotentiometer : System.Exception
    {
        public MaxRangePotentiometer()
            : base("Max range potentiometer") { }
        
    }
}
