﻿using EDA.Logic.Communication;
using EDA.Model.Device;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace EDA.Components.EDAScopeTab
{
    /// <summary>
    /// Logika interakcji dla klasy TabScope.xaml
    /// </summary>
    public partial class EDAScopeTab : UserControl, INotifyPropertyChanged
    {

        public event Action ClearEvent;
        public event Action InitFalse;
        public event Action<String> RbMode;

        public EDAScopeTab()
        {
            InitializeComponent();
            this.DataContext = new EDAScopeTabMV();
            ((EDAScopeTabMV)this.DataContext).InitFalse = InitFalseAction;
            ((EDAScopeTabMV)this.DataContext).ClearEvent = CleareAction;
        }


        private void InitFalseAction()
        {
            InitFalse();
        }

        private void CleareAction()
        {
            ClearEvent();
        }

        private void SetPotentiometer(object sender, DragCompletedEventArgs e)
        {
            double value = SliderPot.Value;
            var dc = (EDAScopeTabMV)this.DataContext;
            dc.SetPotentiometer(value);
        }

        private void SetAmplifier(object sender, EventArgs e)
        {
            string value = ComboBoxAmp.Text;
            var dc = (EDAScopeTabMV)this.DataContext;
            dc.SetAmplifier(value);
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            String value = rb.Content.ToString();
            RbMode?.Invoke(value);
        }

        private void AutoAmp_Checked(object sender, RoutedEventArgs e)
        {
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.AutoAmp =
                (this.DataContext as EDAScopeTabMV).EDAScopeTabModel.AmplifierAuto;
        }

        private void AutoPot_Checked(object sender, RoutedEventArgs e)
        {
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.AutoPot =
                (this.DataContext as EDAScopeTabMV).EDAScopeTabModel.PotentiometerAuto;
        }


        #region INotifyPropertyChanged implementation

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }



        #endregion

    }
}
