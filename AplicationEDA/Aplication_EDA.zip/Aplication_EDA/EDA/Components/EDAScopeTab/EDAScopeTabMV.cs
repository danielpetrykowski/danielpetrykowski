﻿using EDA.Logic.Communication;
using EDA.Model.View;
using EDA.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;

namespace EDA.Components.EDAScopeTab
{
    public class EDAScopeTabMV
    {
        private EDAScopeTabModel eDAScopeTabModel;
        public Action ClearEvent;
        public Action InitFalse;
        public EDAScopeTabMV()
        {
            eDAScopeTabModel = new EDAScopeTabModel();
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.autoControl.AmplifierEvent += SetComboBoxAmp;
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.autoControl.PotentiometerEvent += SetSliderPot;
            eDAScopeTabModel.StartStopCommand = new RelayCommand(x => { StartStopButton_Click(); }, x => true);
            eDAScopeTabModel.ClearCommand = new RelayCommand(x => { ClearButton_Click(); }, x => true);
        }

        private void StartStopButton_Click()
        {
            bool state = StartStopButton();
            if (!state)
                InitFalse();
        }

        private void ClearButton_Click()
        {
            Clear_Click();
            ClearEvent?.Invoke();
        }

        public EDAScopeTabModel EDAScopeTabModel
        {
            get
            {
                return eDAScopeTabModel;
            }
            set
            {
                eDAScopeTabModel = value;
            }
        }

        public bool StartStopButton()
        {
            if (!EDAScopeTabModel.IsStart)
            {
                CommandEDA.VoltageBridge();
                Thread.Sleep(100);
                CommandEDA.StartEDA();
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.device.StartTime = DateTime.Now;
                EDAScopeTabModel.IsStart = true;
                EDAScopeTabModel.StartStopBL = "Stop";
                if (EDAScopeTabModel.Init == false)
                {
                    EDAScopeTabModel.Init = true;
                    return false;
                }
            }
            else
            {
                CommandEDA.StopEDA();
                EDAScopeTabModel.IsStart = false;
                EDAScopeTabModel.StartStopBL = "Start";
            }
            return true;
        }

        public void SetPotentiometer(double value)
        {
            CommandEDA.Potentiometer(new List<int> { (int)value });
        }

        public void SetAmplifier(string value)
        {
            CommandEDA.Amplifier(new List<int> { int.Parse(value) });
        }

        public void Clear_Click()
        {
            if(!EDAScopeTabModel.IsStart)
                EDAScopeTabModel.Init = false;
        }

        public void SetSliderPot(int value)
        {
            eDAScopeTabModel.PotentiometerStatus = value;
        }

        public void SetComboBoxAmp(int value)
        {
            if (eDAScopeTabModel.possibleAmp.Contains(value.ToString()))
                eDAScopeTabModel.AmplifierStatus = value.ToString();
        }
    }
}
