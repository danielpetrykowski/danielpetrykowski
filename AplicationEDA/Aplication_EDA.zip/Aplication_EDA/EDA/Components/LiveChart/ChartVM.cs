﻿using EDA.Logic;
using EDA.Logic.Communication;
using EDA.Model;
using EDA.Model.Data;
using EDA.Model.View;
using System;
using System.Collections.Generic;
using System.Windows;

namespace EDA.Components.LiveChart
{
    public class ChartVM
    {
        private ChartModel chartModel;
        private DateTime startTime;
        private bool modeRes;
        
        public ChartVM()
        {
            chartModel = new ChartModel();
            Engine.measureData += Read;
            modeRes = true;
            ChartModel.LabelY = "Resistance [kΩ]";
            UpdateStartTime();
            InitAxis();
        }
        public ChartModel ChartModel
        {
            get
            {
                return chartModel;
            }
            set
            {
                chartModel = value;
            }
        }

        private void Read(DateTime now, double value)
        {
            if (modeRes)
            {
                ChartModel.ChartValues.Add(new ChartData
                {
                    Time = now - startTime,
                    Value = value
                });
            }
            else
            {
                ChartModel.ChartValues.Add(new ChartData
                {
                    Time = now - startTime,
                    Value = 1/value
                });
            }

            SetAxisLimits(now - startTime);

            if (ChartModel.ChartValues.Count > 250) ChartModel.ChartValues.RemoveAt(0);
        }

        private void SetAxisLimits(TimeSpan period)
        {
            if (period.TotalSeconds > 15)
            {
                ChartModel.AxisMax = period.Ticks + TimeSpan.FromSeconds(1).Ticks;
                ChartModel.AxisMin = period.Ticks - TimeSpan.FromSeconds(15).Ticks;
            }
        }

        public void InitAxis()
        {
            ChartModel.AxisMin = TimeSpan.FromSeconds(0).Ticks;
            ChartModel.AxisMax = TimeSpan.FromSeconds(16).Ticks;
        }

        public void UpdateStartTime()
        {
            startTime = DateTime.Now;
        }

        public void Clear()
        {
            ChartModel.ChartValues.Clear();
        }

        public void ChangeY(String mode)
        {
            bool modeBool;
            modeBool = (mode.Equals("Resistance")) ? true : false;
            if (modeRes==true && modeBool == false)
            {
                modeRes = modeBool;
                Clear();
                ChartModel.LabelY = "Conductance [mS]";
                List<MeasureData> data = (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.data.MeasureDatas;
                if (data.Count > 0)
                {
                    int indeks;
                    if (data.Count > 250)
                    {
                        indeks = data.Count - 250;
                    }
                    else
                    {
                        indeks = 0;
                    }
                    for (; indeks < data.Count; indeks++)
                    {
                        ChartModel.ChartValues.Add(new ChartData
                        {
                            Time = data[indeks].Time - startTime,
                            Value = data[indeks].ValueCon,
                        });
                    }
                }
            }
            else if(modeRes==false && modeBool == true)
            {
                modeRes = modeBool;
                Clear();
                ChartModel.LabelY = "Resistance [kΩ]";
                List<MeasureData> data = (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).conData.engine.data.MeasureDatas;
                if (data.Count > 0)
                {
                    int indeks;
                    if (data.Count > 250)
                    {
                        indeks = data.Count - 250;
                    }
                    else
                    {
                        indeks = 0;
                    }
                    for (; indeks < data.Count; indeks++)
                    {
                        ChartModel.ChartValues.Add(new ChartData
                        {
                            Time = data[indeks].Time - startTime,
                            Value = data[indeks].ValueRes,
                        });
                    }
                }
            }
        }
    }
}
