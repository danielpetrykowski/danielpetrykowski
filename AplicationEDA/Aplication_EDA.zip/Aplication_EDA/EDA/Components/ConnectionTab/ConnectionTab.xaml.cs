﻿using EDA.Logic;
using EDA.Logic.Communication;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EDA.Components.ConnectionTab
{
    /// <summary>
    /// Logika interakcji dla klasy TabConnection.xaml
    /// </summary>
    public partial class TabConnection : UserControl
    {
        public TabConnection()
        {
            InitializeComponent();
            this.DataContext = new ConnectionTabMV();
        }

       
    }
}
