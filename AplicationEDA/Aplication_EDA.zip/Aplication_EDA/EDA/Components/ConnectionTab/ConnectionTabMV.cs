﻿using EDA.Logic.Communication;
using EDA.Model.View;
using EDA.Utility;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EDA.Components.ConnectionTab
{
    public class ConnectionTabMV
    {
        private ConnectionTabModel connectionTabModel;

        public ConnectionTabMV()
        {
            connectionTabModel = new ConnectionTabModel();
            (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).IsActiveAction += ChangeIsActive;
            ConnectionTabModel.IsActive = false;
            InitComboBox();
            ConnectionTabModel.ConnectCommand = new RelayCommand(x => { Connect(); }, x => true);
            ConnectionTabModel.RefreshCommand = new RelayCommand(x => { Refresh(); }, x => true);
        }

        public ConnectionTabModel ConnectionTabModel
        {
            get
            {
                return connectionTabModel;
            }
            set
            {
                connectionTabModel = value;
            }
        }

        private void ChangeIsActive(bool value)
        {
            ConnectionTabModel.IsActive = value;
        }

        private void InitComboBox()
        {
            ConnectionTabModel.PortsNameList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).portsName.ForEach(x => ConnectionTabModel.PortsNameList.Add(x));
            ConnectionTabModel.ConnectionSpeedList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).connectionSpeed.ForEach(x => ConnectionTabModel.ConnectionSpeedList.Add(x));
            ConnectionTabModel.DataBitsList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).dataBits.ForEach(x => ConnectionTabModel.DataBitsList.Add(x));
            ConnectionTabModel.ParityList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).parity.ForEach(x => ConnectionTabModel.ParityList.Add(x));
            ConnectionTabModel.StopBitsList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).stopBits.ForEach(x => ConnectionTabModel.StopBitsList.Add(x));
            ConnectionTabModel.Baudrate = "9600";
            ConnectionTabModel.DataBits = "8";
            ConnectionTabModel.ParityBits = "None";
            ConnectionTabModel.StopBits = "One";
        }

        private void Refresh()
        {
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).Refresh();
            ConnectionTabModel.PortsNameList.Clear();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).portsName.ForEach(x => ConnectionTabModel.PortsNameList.Add(x));
        }

        private void Connect()
        {
            if ((Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).IsActive)
            {
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).ConnectClose();
            }
            else
            {
                try
                {
                    (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).PortName = ConnectionTabModel.PortName;
                    (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).BaudRate = Int32.Parse(ConnectionTabModel.Baudrate);
                    (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).DataBits = Int32.Parse(ConnectionTabModel.DataBits);
                    (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).Parity = (Parity)Enum.Parse(typeof(Parity), ConnectionTabModel.ParityBits);
                    (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).StopBits = (StopBits)Enum.Parse(typeof(StopBits), ConnectionTabModel.StopBits);
                    (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).ConnectOpen();
                    ConnectionTabModel.InfoTextBox = "";
                }
                catch (Exception exc)
                {
                    ConnectionTabModel.InfoTextBox = "Błąd połączenia";
                }
            }
        }
    }
}
