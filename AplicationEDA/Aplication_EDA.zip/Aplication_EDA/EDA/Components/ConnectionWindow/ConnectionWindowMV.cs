﻿using EDA.Logic.Communication;
using EDA.Model.View;
using EDA.Utility;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EDA.Components.ConnectionWindow
{
    public class ConnectionWindowMV
    {
        private ConnectionWindowModel connectionWindowModel;
        public Action CloseConWindowAction;

        public ConnectionWindowMV()
        {
            connectionWindowModel = new ConnectionWindowModel();
            InitComboBox();
            ConnectionWindowModel.ConnectCommand = new RelayCommand(x => { Connect(); }, x => true);
            ConnectionWindowModel.RefreshCommand = new RelayCommand(x => { Refresh(); }, x => true);
        }

        public ConnectionWindowModel ConnectionWindowModel
        {
            get
            {
                return connectionWindowModel;
            }
            set
            {
                connectionWindowModel = value;
            }
        }

        private void InitComboBox()
        {
            ConnectionWindowModel.PortsNameList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).portsName.ForEach(x => ConnectionWindowModel.PortsNameList.Add(x));
            ConnectionWindowModel.ConnectionSpeedList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).connectionSpeed.ForEach(x => ConnectionWindowModel.ConnectionSpeedList.Add(x));
            ConnectionWindowModel.DataBitsList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).dataBits.ForEach(x => ConnectionWindowModel.DataBitsList.Add(x));
            ConnectionWindowModel.ParityList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).parity.ForEach(x => ConnectionWindowModel.ParityList.Add(x));
            ConnectionWindowModel.StopBitsList = new ObservableCollection<string>();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).stopBits.ForEach(x => ConnectionWindowModel.StopBitsList.Add(x));
            ConnectionWindowModel.Baudrate = "9600";
            ConnectionWindowModel.DataBits = "8";
            ConnectionWindowModel.ParityBits = "None";
            ConnectionWindowModel.StopBits = "One";
        }


        private void Refresh()
        {
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).Refresh();
            ConnectionWindowModel.PortsNameList.Clear();
            (Application.Current.Resources["availableSerialPorts"] as AvailableSerialPorts).portsName.ForEach(x => ConnectionWindowModel.PortsNameList.Add(x));
        }


        private void Connect()
        {
            try
            {
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).PortName = ConnectionWindowModel.PortName;
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).BaudRate = Int32.Parse(ConnectionWindowModel.Baudrate);
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).DataBits = Int32.Parse(ConnectionWindowModel.DataBits);
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).Parity = (Parity)Enum.Parse(typeof(Parity), ConnectionWindowModel.ParityBits);
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).StopBits = (StopBits)Enum.Parse(typeof(StopBits), ConnectionWindowModel.StopBits);
                bool state = (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).ConnectOpen();
                if (state == true)
                {
                    CloseConWindowAction();
                }
            }
            catch (Exception exc)
            {
            }
        }
    }
}
