﻿using EDA.Logic;
using EDA.Logic.Communication;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EDA.Components.ConnectionWindow
{
    /// <summary>
    /// Logika interakcji dla klasy ConnectionWindow.xaml
    /// </summary>
    public partial class ConnectionWindow : Window
    {
        public ConnectionWindow()
        {
            InitializeComponent();
            this.DataContext = new ConnectionWindowMV();
            ((ConnectionWindowMV)this.DataContext).CloseConWindowAction = CloseConWindow;
        }

        private void CloseConWindow()
        {
            this.Close();
        }
    }
}
