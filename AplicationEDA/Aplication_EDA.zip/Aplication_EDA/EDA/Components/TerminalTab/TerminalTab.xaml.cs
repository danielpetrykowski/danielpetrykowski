﻿using EDA.Logic;
using EDA.Logic.Communication;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EDA.Components.TerminalTab
{
    /// <summary>
    /// Logika interakcji dla klasy TerminalTab.xaml
    /// </summary>
    public partial class TerminalTab : UserControl
    {
        delegate void Delegat1();
        Action<string> moj_del1;

        public TerminalTab()
        {
            InitializeComponent();
            Receiver.clearData += DataRecievedHandler;
            moj_del1 = new Action<string>(WypiszOdebrane);
        }
        
        private void DataRecievedHandler(string data)
        {
            Dispatcher.Invoke(moj_del1, data);
        }

        private void WypiszOdebrane(String data)
        {
            ReceiveTextBox.AppendText(data);
            ReceiveTextBox.ScrollToEnd();
        }

        private void WyslijDane(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string value = SendTextBox.ToString();
                (Application.Current.Resources["activeSerialPort"] as ActiveSerialPort).Write(value);
            }
        }
    }
}
